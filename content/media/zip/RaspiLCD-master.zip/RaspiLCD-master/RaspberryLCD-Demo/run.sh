#!/bin/bash

java -jar -Djava.library.path=/home/pi/LCD/raspberryJava/svnSource/library/RaspiLCD_V0.9.0/ "$@"
