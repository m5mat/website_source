make clean
make
sudo ./raspilcd